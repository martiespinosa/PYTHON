def suma(num1,num2):
    print("El resultado de la suma es: ", num1+num2)

def resta(num1,num2):
    print("El resultado de la resta es: ", num1-num2)