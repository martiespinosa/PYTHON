from setuptools import setup

setup(name="Paquete distribuible de Cálculos", version="1.0", description="Paquete de càlulos básicos", author="Marti", packages=["paquete", "paquete.operaciones_basicas"])